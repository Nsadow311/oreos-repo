ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Recruit Stopper"
ENT.Author = "Anthony Fuller"
ENT.Category = "Recruit Stopper"
ENT.Spawnable = true
ENT.Contact = "A admin"
