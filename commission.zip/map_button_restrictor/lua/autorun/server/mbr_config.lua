MBR = MBR or {}
MBR.config = MBR.config or {}

local config = MBR.config

config.main = {
    ["rp_stardestroyer_v2_5"] = {
        ["2232"] = {
            teams = { ["Gun Dealer"] = true },
            usergroups = { ["superadmin"] = true, ["admin"] = true },
        },
    },
}
