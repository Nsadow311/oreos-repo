hook.Add( "PlayerUse", "MBR_PlayerUse", function( ply, ent )

    local map = tostring(game.GetMap())
    local creationid = tostring(ent:MapCreationID())
    local stringteam = tostring(ply:Team())

    if !MBR.config.main[map] then return end

    if MBR.config.main[map][creationid] then

        if MBR.config.main[map][creationid]["usergroups"][ply:GetUserGroup()] or MBR.config.main[map][creationid]["teams"][team.GetName(ply:Team())] then
            return true
        else
            return false
        end

    end

end )
